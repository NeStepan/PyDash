import pygame
import random
import os
lofset = 0
WonOfset = 0
class editor:
    def __init__(self):
        self.opened = False
        self.selected = 1
        self.Olist = []
        self.FileName = ""
        self.of = os.listdir("Data/obj/")
    def update(self, screen, plr):
        screen.fill((82, 122, 173))
        for i in range(21):
            for i2 in range(10):
                screen.blit(pygame.image.load("Data/UI/frame.png"), (i*50,i2*50))
        for i in self.Olist:
            siz = 50
            if i.read()[0] == 3 or  i.read()[0] == 4 or  i.read()[0] == 5:
                siz = 25
            x = int(i.read()[1])*siz
            if plr.x + 1100 >= x >= plr.x - 100:
                if i.read()[0] != 0:   
                    obj = i.read()
                    imj = pygame.image.load("Data/obj/"+str(obj[0])+".png")
                    y = int(obj[2])*siz
                    screen.blit(imj, (x-plr.x,y))            
        screen.blit(pygame.transform.scale(pygame.image.load("Data/UI/back.png"), (50, 50)), (10, 10))
        screen.blit(pygame.image.load("Data/UI/block_frame.png"), (0, 500))
        count = -1
        for i in self.of:
            if i != "0.png":
                count += 1
                pygame.draw.rect(screen, (255, 255, 255), (count*100 + 30, 515, 90, 90))
                pygame.draw.rect(screen, (194, 194, 194), (count*100 + 30, 515, 90, 90), 5)
                if i[:-4] == str(self.selected):
                    pygame.draw.rect(screen, (142, 138, 201), (count*100 + 30, 515, 90, 90), 5)
                screen.blit(pygame.image.load("Data/obj/"+i), (count*100 + 50, 545))
        
    def OnClick(self, pos, Type, lis, plr, lvl):
        if self.opened == True:
            if Type == True:
                if  10 <= pos[0] <= 60 and 10 <= pos[1] <= 60 :
                    self.opened = False
                    lis.opened = True
                    Save.save(self.Olist, self.FileName, lvl.song)
                plce = True
                
                for i in self.Olist:
                    siz = 50
                    if self.selected == 3 or  self.selected == 4 or  self.selected == 5:
                        siz = 25                    
                    if i.read()[1] == pos[0] //siz+plr.x//siz and  i.read()[2] == pos[1] // siz:
                        plce = False
                if plce == True and pos[1] <= 500:
                    siz = 50
                    if self.selected == 3 or  self.selected == 4 or  self.selected == 5:
                        siz = 25                     
                    self.Olist.append(Obj(self.selected, pos[0]//siz+plr.x//siz, pos[1]//siz))
            else: 
                plce = False
                ix = 0
                for i in self.Olist:                 
                    siz = 50
                    if self.selected == 3 or  self.selected == 4 or  self.selected == 5:
                        siz = 25
                    if i.read()[1] == pos[0]//siz+plr.x//siz and  i.read()[2] == pos[1] // siz:
                        plce = True
                        ix = self.Olist.index(i)
                if plce == True:
                    self.Olist.pop(ix)
        
class menu:
    def __init__(self, lis):
        self.opened = True
        
    def update(self, screem):
        screem.blit(pygame.image.load("Data/UI/menu.png"), (0, 0))
    
    def OnClick(self, pos):
        if self.opened == True:
            if  292 <= pos[0] <= 385 and 253 <= pos[1] <= 345:
                print("Yam!")
            if  464 <= pos[0] <= 558 and 253 <= pos[1] <= 345:
                self.opened = False
                lis.Type = 0
                lis.folder = "Data/OfLevels/"
                lis.opened = True
                lis.sp = os.listdir("Data/OfLevels/")
            if  640 <= pos[0] <= 735 and 253 <= pos[1] <= 345:
                self.opened = False
                lis.Type = 1
                lis.folder = "Data/Levels/"
                lis.sp = os.listdir("Data/Levels/")
                lis.opened = True            
            
            
            
class list:
    def __init__(self, folder):
        self.Type = 0
        self.folder = folder
        self.opened = False
        self.sp = os.listdir(self.folder)
    def update(self, screem, ofset):     
        screem.fill((32, 88, 102))
        text = pygame.font.SysFont(None, 50)
        for i in self.sp:           
            ix = self.sp.index(i)
            pygame.draw.rect(screem, (115, 56, 0), (211, 56+ix*110-ofset, 600, 100))
            pygame.draw.rect(screem, (84, 41, 0), (211, 56+ix*110-ofset, 600, 100), 5)
            nam = text.render(os.path.basename(i)[:-4], True, (255, 255, 255))
            screem.blit(nam,(301, 81+ix*110-ofset))
            screem.blit(pygame.image.load("Data/UI/play.png"), (711, 81+ix*110-ofset))
            if self.Type == 1:
                screem.blit(pygame.image.load("Data/UI/edit.png"), (651, 81+ix*110-ofset))
        screem.blit(pygame.image.load("Data/UI/listbg.png"), (0, 0))
        screem.blit(pygame.image.load("Data/UI/back.png"), (10, 10))
        if self.Type == 1:
            screem.blit(pygame.image.load("Data/UI/plus.png"), (962, 550))        
            
        
    def OnClick(self, pos, ofset, lvl, plr, men, edi):
        if self.opened == True:
            for i in self.sp:           
                ix = self.sp.index(i)
                if 81 + ix * 110-ofset <= pos[1] <= 81 + ix * 110-ofset + 50 and 711 <= pos[0] <= 761:
                    lvl.list = Save.read(self.folder+os.path.basename(i), plr)
                    lvl.playing = True
                    lvl.song = Save.readSong(self.folder+os.path.basename(i))
                    self.opened = False
                    plr.ofset = 700
                if self.Type == 1:
                    if 81 + ix * 110-ofset <= pos[1] <= 81 + ix * 110-ofset + 50 and 651 <= pos[0] <= 701:
                        self.opened = False
                        edi.Olist = Save.read("Data/Levels/"+ i, cube)
                        edi.FileName = i
                        edi.opened = True
            if 962 <= pos[0] <= 962 + 50 and 550 <= pos[1] <= 600 and self.Type == 1:
                name =  str(len(os.listdir("Data/Levels/")))
                file = open("Data/Levels/level"+name+".lvl", "w+")
                file.close()
                self.sp = os.listdir("Data/Levels/")
                
            if  10 <= pos[0] <= 105 and 10 <= pos[1] <= 105:
                self.opened = False
                men.opened = True
                
        if lvl.Wofset == 252: 
            lvl.playing = False
            self.opened = True
            lvl.Wofset = 0
class Save:
    def save(Wlist,File_name, song):
        file = open("Data/Levels/"+File_name, "w")
        file.write("#"+song+"\n")
        for item in Wlist:
            file.write(str(item.read()[0])+","+str(item.read()[1])+","+str(item.read()[2])+"\n")
        file.close()
    def read(File_name, plr):
        plr.x = 0
        file = open(File_name)
        Nlist = []
        for line in file:
            if line[:1] != "#":
                edited = line.split(",")
                edited[2] = edited[2][:-1]
                Nlist.append(Obj(edited[0],edited[1],edited[2]))
        return Nlist
    def readSong(File_name):
        file = open(File_name)
        song = 2
        for line in file:
            if line[:1] == "#":
                song = line[1:-2]
                print(line[1:-2])
        return song       
        
class Cube:
    def __init__(self, skin = 1):
        self.x = 0
        self.y = 450
        self.ofset = 140
        self.skin = skin
        self.jump = 0
        self.alive = True
        self.reset = 0
        self.imj = pygame.image.load("Data/Cubes/"+str(self.skin)+".png")
        
    def Death(self):
        pygame.mixer.stop()
        self.alive = False
        if self.reset == 0:
            self.reset = 60
        if self.reset != 0:
            self.reset -= 1
        if self.reset == 0:
            self.alive = True
            self.x = 0
            self.y = 450
            self.ofset = 140
        
        
    def update(self, screem, Wlist):  
        if self.alive == True:
            screem.blit(self.imj, (70-self.ofset, self.y))
            
            
        if self.jump > 150:
            self.y -= 10
            
        elif self.jump > 0:
            self.y += 10
            
        else:
            self.y += 10
            
        if self.jump != 0:
            self.jump -= 10
        
        for obg in Wlist:
            if obg.read()[0] == 2:
                if int(obg.read()[1])*50 +10 <= self.x +25 <= int(obg.read()[1])*50 + 40: 
                    if int(obg.read()[2])*50 +10 <= self.y +25 <= int(obg.read()[2])*50 + 40:
                        self.Death()
                            
            elif obg.read()[0] == 3 or obg.read()[0] == 4 or obg.read()[0] == 5:
                if int(obg.read()[1])*25 <= self.x <= int(obg.read()[1])*25+25: 
                    if  int(obg.read()[2])*25 <= (self.y +50) <= int(obg.read()[2])*25+25:
                        self.jump = 0
                        self.y = int(obg.read()[2])*25 - 51

                elif int(obg.read()[1])*25 <= self.x +75 <= int(obg.read()[1])*25+25: 
                    if  int(obg.read()[2])*25 <= (self.y +50) <= int(obg.read()[2])*25+25:
                        self.jump = 0
                        self.y = int(obg.read()[2])*25 - 51

                            
                            
            else:
                    if int(obg.read()[1])*50 <= self.x +50 <= int(obg.read()[1])*50+50: 
                        if  int(obg.read()[2])*50 <= (self.y +50) <= int(obg.read()[2])*50+50:
                            self.jump = 0
                            self.y = int(obg.read()[2])*50 - 51
                            
                    elif int(obg.read()[1])*50 <= self.x +100 <= int(obg.read()[1])*50+50: 
                        if  int(obg.read()[2])*50 <= (self.y +50) <= int(obg.read()[2])*50+50:
                            self.jump = 0
                            self.y = int(obg.read()[2])*50 - 51
                    
                    if int(obg.read()[1])*50 <= self.x +100 <= int(obg.read()[1])*50+50:
                        if  int(obg.read()[2])*50 <= (self.y +40) <= int(obg.read()[2])*50+50:
                            self.Death()
                    if int(obg.read()[1])*50 <= self.x +100 <= int(obg.read()[1])*50+50:
                        if  int(obg.read()[2])*50 <= (self.y + 15) <= int(obg.read()[2])*50+50:
                            self.Death()            
                    elif int(obg.read()[1])*50 <= self.x +50 <= int(obg.read()[1])*50+50:
                        if  int(obg.read()[2])*50 <= (self.y + 15) <= int(obg.read()[2])*50+50:
                            self.Death()
            if self.y >= 460:
                self.y = 450
        if self.alive == False:
            self.Death()
        
     
         
class Level:
    def __init__(self):
        self.playing = False
        self.list = []
        self.Wofset = -100
        self.song = ""
    def update(self, obj_list, screem, bg, plr):
        bg = pygame.image.load("Data/bg/"+str(bg)+".png")
        screem.blit(bg, (0,0))
        mux = 0
            
        for i in obj_list:
            siz = 50
            if i.read()[0] == 3 or  i.read()[0] == 4 or  i.read()[0] == 5:
                siz = 25
            if i.read()[1] * siz > mux and i.read()[0] != 0:
                mux = i.read()[1] * siz
            x = int(i.read()[1])*siz
            if plr.x + 1100 >= x >= plr.x - 100:
                obj = i.read()
                imj = pygame.image.load("Data/obj/"+str(obj[0])+".png")
                y = int(obj[2])*siz
                screem.blit(imj, (x-plr.x,y))
                
        for i in range(mux//50 + 25):
            if plr.x + 1100 >= i*50 >= plr.x - 100:
                screem.blit(pygame.image.load("Data/obj/0.png"), (i*50 - plr.x, 500))
                
        if plr.alive == True and plr.ofset == 0 and plr.x < mux + 60:
            plr.x += 7
        else:
            plr.ofset -= 7
            
        if plr.ofset < -1000:
            if self.Wofset != 252:
                self.Wofset += 4
            screem.blit(pygame.image.load("Data/UI/won.png"), (262, self.Wofset-38))
        if self.Wofset == 252:
            txt = pygame.font.SysFont(None, 25).render("Tap on screen to exit...", True, (255, 255, 255))
            screem.blit(txt, (5, 580))
class Obj:
    def __init__(self, ID = 0, x = 0, y = 0):
        self.ID = ID
        self.x = x
        self.y = y
    def read(self):
        return [int(self.ID), int(self.x) ,int(self.y)]
    


pygame.init()
pygame.mixer.init()
screen = pygame.display.set_mode((1024, 612))
clock = pygame.time.Clock()
FPS = 60
game_run = True
cube = Cube()
lis = list("Data/OfLevels")
lvl = Level()
men = menu(lis)
edi = editor()
pygame.display.set_icon(pygame.image.load("Data/Cubes/1.png"))
names = ["In Education and Learning!", "FREE!! maybe...", "Fortnite Battle Pass", "https://gamejolt.com/games/FNAF56/897877", "It's real!!! WOW!!!!"]
pygame.display.set_caption("PyDash:  "+names[random.randint(1,5)])
while game_run:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            game_run = False
        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:
                if edi.opened == True:
                    edi.OnClick(pygame.mouse.get_pos(), True, lis, cube, lvl)                
                lis.OnClick(pygame.mouse.get_pos(), lofset, lvl, cube, men, edi)
                men.OnClick(pygame.mouse.get_pos())
                if cube.jump == 0:
                    cube.jump = 300
            if event.button == 3:
                edi.OnClick(pygame.mouse.get_pos(), False, lis, cube, lvl)
            if event.button == 4:
                if lis.opened == True:
                    lofset += 20
                if edi.opened == True and cube.x < 20000:
                    cube.x += 100      
            if event.button == 5:
                if edi.opened == True and cube.x > 0:
                    cube.x -= 100                
                if lofset > 0 and lis.opened == True:
                    lofset -= 20
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE and lvl.playing == True:
                lvl.playing = False
                lis.opened = True 
            if event.key == pygame.K_LEFT and edi.opened == True and cube.x > 0:
                cube.x -= 100
            if event.key == pygame.K_RIGHT and edi.opened == True and cube.x < 20000:
                cube.x += 100
            if event.key == pygame.K_UP and edi.selected < 5 and edi.opened == True:
                edi.selected += 1
            if event.key == pygame.K_DOWN and edi.selected > 1 and edi.opened == True:
                edi.selected -= 1                
                    
    if lis.opened == True:
        lis.update(screen, lofset)    
    if lvl.playing == True:
        lvl.update(lvl.list, screen, 1, cube)
        cube.update(screen, lvl.list)
    if men.opened == True:
        men.update(screen)
    if edi.opened == True:
        edi.update(screen, cube)
    
    pygame.display.flip()
    clock.tick(FPS)
pygame.quit()